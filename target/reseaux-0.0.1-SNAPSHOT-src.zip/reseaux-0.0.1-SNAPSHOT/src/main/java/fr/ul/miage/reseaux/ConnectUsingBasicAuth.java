package fr.ul.miage.reseaux;

public class ConnectUsingBasicAuth {

}
